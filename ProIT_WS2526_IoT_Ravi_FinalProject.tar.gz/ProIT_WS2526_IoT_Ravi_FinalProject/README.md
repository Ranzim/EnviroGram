# ProIT_WS2526_IoT_Ravi_FinalProject

IoT Project winter semester 2025/26

## Components

### Hardware
* Microcontroller ESP32
* DHT22 Temperature & Humidity Sensor
* Raspberry Pi 3

### Software
* Node-Red
   * Telegram Nodes
   * MQTT Nodes
   * Dashboard Nodes
* Mosquitto Broker

## Repo Structure

```
.
├── Documentation
│   ├── setup_guide.md
│   └── dew_point_info.md
├── Hardware
│   └── ESP32
│       └── esp32_dht22.ino
├── Node-Red
│   └── telegram_alert_flow.json
├── RaspberryPi
│   └── mqtt_setup.md
└── README.md
```

## ESP32 Firmware

The ESP32 reads temperature and humidity from the DHT22 sensor and publishes to MQTT.

### DHT22 Sensor Reading

The DHT22 sensor is connected to GPIO pin 4:

```cpp
#include <DHT.h>

#define DHTPIN 4
#define DHTTYPE DHT22

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  dht.begin();
}

void loop() {
  float temperature = dht.readTemperature();
  float humidity = dht.readHumidity();
  
  if (!isnan(temperature) && !isnan(humidity)) {
    // Publish to MQTT
  }
}
```

### WiFi Connection

```cpp
#include <WiFi.h>

const char* ssid = "YourSSID";
const char* password = "YourPassword";

void setup() {
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
  }
}
```

### MQTT Publishing

```cpp
#include <PubSubClient.h>

const char* mqtt_server = "192.168.1.100";
const char* topic_temp = "home/ravi/temperature";
const char* topic_humi = "home/ravi/humidity";

WiFiClient espClient;
PubSubClient client(espClient);

void publishData(float temp, float humi) {
  client.publish(topic_temp, String(temp).c_str());
  client.publish(topic_humi, String(humi).c_str());
}
```

## Node-Red Flow

### (1) Dashboard

The dashboard displays temperature, humidity, and dew point in real-time with gauges and charts.

### (2) MQTT Subscription

MQTT nodes subscribe to topics from ESP32:
- `home/ravi/temperature`
- `home/ravi/humidity`

### (3) Dew Point Calculation

Function node calculates dew point using Magnus-Tetens formula:

```javascript
var temp = msg.payload.temperature;
var humidity = msg.payload.humidity;

var a = 17.27;
var b = 237.7;

var alpha = ((a * temp) / (b + temp)) + Math.log(humidity/100.0);
var dewPoint = (b * alpha) / (a - alpha);

msg.payload.dewPoint = dewPoint.toFixed(2);
return msg;
```

### (4) Telegram Bot

Telegram receiver listens for commands like `/start` and `/status`.

### (5) Alert System

Alerts are sent when temperature or humidity exceeds thresholds with hysteresis logic:

```javascript
var temp = msg.payload.temperature;
var threshold_high = 28;
var threshold_low = 26;

if (temp > threshold_high && !context.get('alertActive')) {
    context.set('alertActive', true);
    msg.payload = "⚠️ High temperature: " + temp + "°C";
    return msg;
} else if (temp < threshold_low && context.get('alertActive')) {
    context.set('alertActive', false);
    msg.payload = "✅ Temperature normal: " + temp + "°C";
    return msg;
}
```

### (6) Complete Flow

The integrated system combines sensor data, calculations, visualization, and alerts.

## Installation

### Raspberry Pi Setup

```bash
# Install Mosquitto
sudo apt-get install mosquitto mosquitto-clients

# Install Node-RED
bash <(curl -sL https://raw.githubusercontent.com/node-red/linux-installers/master/deb/update-nodejs-and-nodered)

# Install Node-RED packages
cd ~/.node-red
npm install node-red-dashboard
npm install node-red-contrib-telegrambot
```

### ESP32 Setup

1. Install Arduino IDE
2. Add ESP32 board support
3. Install libraries: DHT sensor library, PubSubClient
4. Configure WiFi and MQTT settings
5. Upload sketch to ESP32

### Node-RED Flow

1. Open Node-RED at `http://<raspberry-pi-ip>:1880`
2. Import `telegram_alert_flow.json`
3. Configure Telegram bot token
4. Deploy the flow

## Dew Point

Dew point is calculated using the Magnus-Tetens formula:

```
α = (17.27 × T) / (237.7 + T) + ln(RH/100)
Td = (237.7 × α) / (17.27 - α)
```

Where:
- T = Temperature in °C
- RH = Relative Humidity in %
- Td = Dew Point in °C

Dew point indicates comfort level:
- < 10°C: Comfortable
- 10-16°C: Acceptable  
- 16-21°C: Uncomfortable
- > 21°C: Very uncomfortable
