# MQTT Setup on Raspberry Pi

## Install Mosquitto

```bash
sudo apt-get update
sudo apt-get install mosquitto mosquitto-clients
```

## Configure Authentication

```bash
# Create password file
sudo mosquitto_passwd -c /etc/mosquitto/passwd ravi

# Edit configuration
sudo nano /etc/mosquitto/mosquitto.conf
```

Add these lines:
```
allow_anonymous false
password_file /etc/mosquitto/passwd
```

## Restart Mosquitto

```bash
sudo systemctl restart mosquitto
sudo systemctl enable mosquitto
```

## Test MQTT

```bash
# Subscribe to topic
mosquitto_sub -h localhost -t "home/ravi/temperature" -u ravi -P password

# Publish test message
mosquitto_pub -h localhost -t "home/ravi/temperature" -m "25.5" -u ravi -P password
```

## Topics Used

- `home/ravi/temperature` - Temperature data from ESP32
- `home/ravi/humidity` - Humidity data from ESP32
- `home/ravi/status` - Connection status
