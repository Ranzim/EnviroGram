# Dew Point Calculation

## What is Dew Point?

Dew point is the temperature at which air becomes saturated and water vapor condenses into liquid droplets.

## Magnus-Tetens Formula

```
α = (a × T) / (b + T) + ln(RH/100)
Td = (b × α) / (a - α)
```

Where:
- T = Temperature (°C)
- RH = Relative Humidity (%)
- Td = Dew Point (°C)
- a = 17.27 (constant)
- b = 237.7 (constant)

## Implementation in Node-RED

```javascript
var temp = msg.payload.temperature;
var humidity = msg.payload.humidity;

var a = 17.27;
var b = 237.7;

var alpha = ((a * temp) / (b + temp)) + Math.log(humidity/100.0);
var dewPoint = (b * alpha) / (a - alpha);

msg.payload.dewPoint = dewPoint.toFixed(2);
return msg;
```

## Comfort Scale

| Dew Point (°C) | Comfort Level |
|----------------|---------------|
| < 10 | Very Comfortable |
| 10-13 | Comfortable |
| 13-16 | Acceptable |
| 16-18 | Slightly Uncomfortable |
| 18-21 | Uncomfortable |
| 21-24 | Very Uncomfortable |
| > 24 | Extremely Uncomfortable |

## Example Calculation

Given:
- Temperature: 25°C
- Humidity: 60%

Calculate:
```
α = (17.27 × 25) / (237.7 + 25) + ln(0.6)
α = 431.75 / 262.7 + (-0.511)
α = 1.644 - 0.511 = 1.133

Td = (237.7 × 1.133) / (17.27 - 1.133)
Td = 269.32 / 16.137
Td = 16.69°C
```

Result: Comfortable conditions
