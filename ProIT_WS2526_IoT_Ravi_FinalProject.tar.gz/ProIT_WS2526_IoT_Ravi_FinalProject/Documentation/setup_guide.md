# Setup Guide

## Hardware Setup

### ESP32 Wiring
- DHT22 VCC → ESP32 3V3
- DHT22 DATA → ESP32 GPIO 4
- DHT22 GND → ESP32 GND

### Raspberry Pi
- Install Raspberry Pi OS
- Connect to network

## Software Installation

### Raspberry Pi

```bash
# Update system
sudo apt-get update

# Install Mosquitto MQTT Broker
sudo apt-get install mosquitto mosquitto-clients

# Install Node-RED
bash <(curl -sL https://raw.githubusercontent.com/node-red/linux-installers/master/deb/update-nodejs-and-nodered)

# Start Node-RED
sudo systemctl enable nodered
sudo systemctl start nodered
```

### Node-RED Packages

```bash
cd ~/.node-red
npm install node-red-dashboard
npm install node-red-contrib-telegrambot
sudo systemctl restart nodered
```

### ESP32 Arduino IDE

1. Install Arduino IDE
2. Add ESP32 board: File → Preferences → Additional Board URLs:
   ```
   https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json
   ```
3. Install libraries:
   - DHT sensor library (Adafruit)
   - PubSubClient

## Configuration

### ESP32 Code

Edit in `esp32_dht22.ino`:
```cpp
const char* ssid = "YourWiFiSSID";
const char* password = "YourPassword";
const char* mqtt_server = "192.168.1.100";  // Your Raspberry Pi IP
```

### Telegram Bot

1. Open Telegram, search for @BotFather
2. Send `/newbot`
3. Follow instructions to create bot
4. Copy the bot token
5. Get your chat ID from @userinfobot

### Node-RED

1. Open `http://<raspberry-pi-ip>:1880`
2. Import `telegram_alert_flow.json`
3. Configure Telegram nodes with your bot token
4. Deploy

## Testing

1. Power on ESP32
2. Check Serial Monitor (115200 baud)
3. Verify WiFi connection
4. Verify MQTT publishing
5. Open Node-RED dashboard
6. Test Telegram bot with `/start`
